# T&J Cleaning Services - Quick Start (30 Minutes)

Get your website live in 30 minutes. Detailed setup? See SETUP_GUIDE.md

---

## ⚡ The Fast Track

### 1️⃣ Vercel Setup (2 minutes)

1. Go to [vercel.com](https://vercel.com) → Sign up (free)
2. Create New Project → Import Git Repo
3. Paste: `https://github.com/yourusername/tj-cleaning-services`
4. Click Import

### 2️⃣ Google Sheets (3 minutes)

1. Go to [sheets.google.com](https://sheets.google.com)
2. Create new sheet → Name it "Requests"
3. Add headers in Row 1:
   ```
   Timestamp | Name | Email | Phone | Address | Sq Ft | Bedrooms | Bathrooms | Service Type | Price | Date | Time | Special Requests | Status | Notes | Email
   ```
4. Copy the sheet ID from the URL
5. Share sheet with your Google Service Account email

### 3️⃣ Google Cloud Setup (5 minutes)

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create Project → Name: "TJ Cleaning"
3. Enable APIs: Search → "Google Sheets API" → Enable
4. Enable APIs: Search → "Gmail API" → Enable
5. Create Credentials → Service Account
   - Name: `tj-service`
   - Role: Editor
   - Create Key → JSON
6. Save the JSON file - you'll need these values:
   - `project_id`
   - `private_key_id`
   - `private_key`
   - `client_email`
   - `client_id`

### 4️⃣ Email Setup (2 minutes)

**Option A (Free): Gmail**
1. Go to [myaccount.google.com](https://myaccount.google.com) → Security
2. Enable 2-Step Verification (if not already)
3. App passwords → Select Mail + Windows Computer
4. Copy the 16-character password

**Option B (Production): SendGrid**
1. Create free account at [sendgrid.com](https://sendgrid.com)
2. Settings → API Keys → Create Key
3. Copy the API key

### 5️⃣ Vercel Environment Variables (3 minutes)

In Vercel dashboard, go to Settings → Environment Variables

Add these:

**Google Sheets:**
```
GOOGLE_PROJECT_ID = [from JSON]
GOOGLE_PRIVATE_KEY_ID = [from JSON]
GOOGLE_PRIVATE_KEY = [from JSON - keep the \n characters]
GOOGLE_CLIENT_EMAIL = [from JSON]
GOOGLE_CLIENT_ID = [from JSON]
GOOGLE_SHEET_ID = [from your sheet URL]
```

**Email (choose one):**

If Gmail:
```
GMAIL_USER = your.email@gmail.com
GMAIL_PASSWORD = [16-char app password]
```

If SendGrid:
```
SENDGRID_API_KEY = [your key]
```

**Other:**
```
OWNER_EMAIL = your.email@gmail.com
REVIEW_EMAIL_API_KEY = random-32-char-string
```

### 6️⃣ Deploy & Test (5 minutes)

1. In Vercel, click "Deploy" or merge to main branch
2. Wait for deployment (2-3 min)
3. Click the deployed URL
4. Test the quote form:
   - Enter: 2000 sq ft, 3 bed, 2 bath, Residential
   - Should show estimated price
5. Test scheduling:
   - Fill in test info
   - Submit
6. Check Google Sheets - row should appear!
7. Check email - should have notifications

### 7️⃣ Google Sheets Automation (5 minutes)

1. Open your Google Sheet
2. Extensions → Apps Script
3. Delete default code
4. Paste content from `sheets-automation.gs`
5. Edit these lines:
   ```javascript
   const WEBHOOK_URL = 'https://your-vercel-domain.vercel.app/api/';
   const REVIEW_EMAIL_API_KEY = '[same as Vercel env var]';
   ```
6. Save
7. Click Triggers (left sidebar) → "+ Create new trigger"
8. Run `onEdit` trigger on changes

### 8️⃣ Customize (5 minutes)

Edit `index.html`:
- Find "555-123-4567" → Replace with your phone
- Find "info@tjcleaning.com" → Replace with your email
- Update business name where needed

Edit pricing in `js/app.js`:
```javascript
const PRICING_RULES = {
    base: 50,              // Change to your base price
    perSquareFoot: 0.15,   // Change to your rate
    bedroomMultiplier: 25, // Change bedroom price
    bathroomMultiplier: 35 // Change bathroom price
};
```

---

## ✅ You're Live!

Your website is now accepting bookings and sending automated emails!

### What Happens Now:
1. **Customer fills quote form** → Instant price calculated
2. **Customer schedules** → Request goes to Google Sheets
3. **You get email** → Notification of new request
4. **Customer gets email** → Confirmation of submission
5. **You approve in Sheets** → Confirmation email sent to customer
6. **Service complete** → Review email sent automatically

---

## 🆘 Quick Troubleshooting

**Quote not calculating?**
- Refresh browser (Ctrl+Shift+R)
- Check F12 console for errors

**Emails not arriving?**
- Check spam folder
- Check Vercel logs: Deployments → Functions
- Check GMAIL_PASSWORD is the app password (16 chars), not your account password

**Google Sheets not updating?**
- Verify GOOGLE_SHEET_ID is correct
- Check sheet is shared with service account
- Look at Vercel logs

**Automation emails not triggering?**
- Make sure Status column is exactly "Status"
- Verify Google Apps Script is saved
- Test manually: T&J Cleaning menu → Send Email

---

## 📚 Need More Help?

- Full setup: See `SETUP_GUIDE.md`
- Sheets details: See `SHEETS_SETUP.md`
- Deployment checklist: See `DEPLOYMENT_CHECKLIST.md`
- Full docs: See `README.md`

---

## 🎯 Key URLs

- **Your Website:** `https://your-project.vercel.app`
- **Vercel Dashboard:** vercel.com/dashboard
- **Google Cloud Console:** console.cloud.google.com
- **Your Google Sheet:** Open from your Drive

---

## ⭐ Pro Tips

1. **Test everything yourself first** - Submit a test quote/booking
2. **Monitor first week** - Check emails and sheets daily
3. **Adjust pricing** - Easy to change PRICING_RULES in js/app.js
4. **Custom domain** - Add in Vercel Settings → Domains (costs ~$10/year)
5. **Backup sheets** - Download CSV weekly to your computer

---

**Done! Your T&J Cleaning Services website is ready to bring in customers!** 🎉
