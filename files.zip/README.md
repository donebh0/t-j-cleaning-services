# T&J Cleaning Services - Professional Website with Automation

A complete, production-ready website for cleaning service businesses with automated quoting, scheduling, and customer engagement tools.

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Status: Ready](https://img.shields.io/badge/Status-Production%20Ready-green.svg)

## Features

### 🎯 Instant Quote System
- Real-time price calculation based on:
  - Square footage
  - Number of bedrooms and bathrooms
  - Service type (Residential, Deep, Office)
- Transparent pricing with no hidden fees
- Beautiful, mobile-responsive quote interface

### 📋 Smart Scheduling
- Customers submit requests directly from the quote
- Automatic integration with Google Sheets
- Business owner receives instant notifications
- Customers get immediate confirmation emails

### ⭐ Review Automation
- Automatic review request emails sent 2 hours after service completion
- Links to Google Maps, Yelp, and Thumbtack
- Increases online visibility and customer ratings
- Built-in feedback collection

### 🔧 Additional Automation
- Email notifications for new requests
- Approval/denial workflow via Google Sheets
- Customer confirmation when appointment is approved
- One-click to send follow-up emails

## Tech Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js Serverless Functions (Vercel)
- **Database**: Google Sheets (simple, cost-free)
- **Email**: Gmail API or SendGrid
- **Hosting**: Vercel (free tier compatible)

## Quick Start

1. **Clone or download** this repository
2. **Deploy to Vercel**: Click "Deploy" or push to GitHub and connect
3. **Set up environment variables** in Vercel dashboard
4. **Configure Google Sheets integration**
5. **Add Google Apps Script** for automation

See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed instructions.

## File Structure

```
.
├── index.html              # Main website
├── css/
│   └── style.css          # Styling
├── js/
│   └── app.js             # Frontend logic
├── api/
│   ├── schedule.js        # Handle form submissions
│   └── review-email.js    # Send review emails
├── sheets-automation.gs   # Google Apps Script
├── package.json           # Dependencies
├── vercel.json           # Deployment config
├── SETUP_GUIDE.md        # Detailed setup
└── .env.local.example    # Environment template
```

## Pricing Calculator

The quote calculator uses these formulas:

```
Base Price: $50
Per Square Foot: $0.15
Per Bedroom: $25
Per Bathroom: $35
Service Multipliers:
  - Residential: 1.0x
  - Deep Cleaning: 1.5x
  - Office: 1.2x
```

Customize these values in `js/app.js` for your business.

## Environment Variables Required

```
# Google Sheets (for automated submissions)
GOOGLE_PROJECT_ID
GOOGLE_PRIVATE_KEY_ID
GOOGLE_PRIVATE_KEY
GOOGLE_CLIENT_EMAIL
GOOGLE_CLIENT_ID
GOOGLE_SHEET_ID

# Email Service (choose one)
GMAIL_USER & GMAIL_PASSWORD  (OR)
SENDGRID_API_KEY

# Configuration
OWNER_EMAIL
REVIEW_EMAIL_API_KEY
```

See `SETUP_GUIDE.md` for how to obtain these values.

## Features in Detail

### Quote Calculator
- Dynamic pricing based on property size
- Service type customization
- Instant results with no page reload
- Schedule button to proceed to booking

### Automated Scheduling
- Beautiful scheduling form
- Email confirmations to customers
- Automatic Google Sheets integration
- Owner receives notifications

### Smart Notifications
1. **Customer Confirmation** - Sent immediately after submission
2. **Owner Notification** - Received for review/approval
3. **Approval Confirmation** - Sent when owner approves in Sheets
4. **Review Request** - Sent 2 hours after service completion

### Google Sheets Workflow
- View all requests in one place
- Approve/Deny requests with status updates
- Automated emails trigger on status changes
- Add notes and special instructions
- Simple, zero-learning-curve interface

## Customization

### Update Pricing
Edit `js/app.js` - `PRICING_RULES` object

### Update Email Templates
Edit the email HTML in:
- `api/schedule.js`
- `api/review-email.js`
- `sheets-automation.gs`

### Update Website Copy
Edit `index.html` directly

### Change Colors
Edit CSS variables in `css/style.css`

### Update Contact Info
Find and replace phone/email in `index.html`

## Deployment

### Deploy to Vercel (Recommended)

1. Push code to GitHub
2. Go to vercel.com → New Project
3. Import from GitHub
4. Add environment variables
5. Deploy!

Your site will be live at: `your-project.vercel.app`

### Custom Domain
1. In Vercel dashboard → Settings → Domains
2. Add your custom domain
3. Update DNS records (instructions provided)

## Mobile Responsive

- ✅ Mobile first design
- ✅ Tablet optimized
- ✅ Desktop full experience
- ✅ Touch-friendly forms
- ✅ Fast load times

## Security

- ✅ Environment variables for all secrets
- ✅ No client-side credentials
- ✅ CORS configured
- ✅ Input validation on backend
- ✅ Google Service Account authentication
- ✅ API key protection for review emails

## Performance

- **Page Load**: < 2 seconds
- **Quote Calculation**: Instant (client-side)
- **Email Delivery**: < 5 minutes
- **Spreadsheet Sync**: Real-time
- **Uptime**: 99.95% (Vercel guarantee)

## Images

All images are stock photos from Unsplash with:
- No faces or identifiable people
- Professional cleaning/office aesthetics
- Ready to use (free license)

To replace images, update the `src` URLs in `index.html`

## Support & Maintenance

### Common Tasks

**Add a new service type:**
1. Edit PRICING_RULES in js/app.js
2. Add option to select in index.html
3. Update email templates

**Change quote calculation:**
Edit js/app.js PRICING_RULES object

**Modify email content:**
Edit the HTML in api/*.js or sheets-automation.gs

**Update business info:**
Edit phone/email throughout index.html

### Monitoring

- Check Vercel dashboard for deployment status
- View function logs for errors
- Monitor email deliverability
- Track Google Sheets submissions

## Troubleshooting

**Quotes not calculating?**
- Check browser console (F12) for JavaScript errors
- Verify all fields are filled
- Clear browser cache

**Emails not sending?**
- Check Vercel function logs
- Verify email credentials
- Confirm recipient email is valid
- Check spam folder

**Google Sheets not updating?**
- Verify sheet ID is correct
- Check service account has access
- Look at Vercel error logs
- Ensure column names match script

**Review emails not triggering?**
- Confirm Apps Script is saved and authorized
- Check that Status column is exactly "Status"
- Verify column order matches script
- Test using manual menu option

See SETUP_GUIDE.md for detailed troubleshooting.

## API Documentation

### POST /api/schedule
Submits a cleaning service request

**Body:**
```json
{
  "customerName": "John Doe",
  "customerEmail": "john@example.com",
  "customerPhone": "(555) 123-4567",
  "address": "123 Main St",
  "squareFootage": 2000,
  "bedrooms": 3,
  "bathrooms": 2,
  "serviceType": "residential",
  "estimatedPrice": 425,
  "preferredDate": "2024-02-15",
  "preferredTime": "10:00",
  "specialRequests": "Please focus on kitchen"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Request submitted successfully"
}
```

### POST /api/review-email
Sends a review request email

**Headers:**
```
x-api-key: [REVIEW_EMAIL_API_KEY]
```

**Body:**
```json
{
  "customerName": "John Doe",
  "customerEmail": "john@example.com"
}
```

## Future Enhancements

- [ ] Payment processing (Stripe)
- [ ] Calendar synchronization
- [ ] Multi-location support
- [ ] Team member assignments
- [ ] Photo gallery uploads
- [ ] Before/after comparisons
- [ ] Mobile app
- [ ] SMS notifications
- [ ] Recurring service management

## Pricing & Costs

- **Website Hosting**: Free (Vercel)
- **Database**: Free (Google Sheets)
- **Email (Gmail)**: Free (up to 500/day)
- **Email (SendGrid)**: Free tier available
- **Domain**: ~$10/year (optional)
- **Total**: Can run completely free!

## License

MIT License - Feel free to use and modify for your business

## Support

For setup help, see [SETUP_GUIDE.md](./SETUP_GUIDE.md)

For updates and support:
- Check Vercel documentation: https://vercel.com/docs
- Review Google Sheets API: https://developers.google.com/sheets/api
- Nodemailer help: https://nodemailer.com/

---

**Ready to get started?** Follow the [SETUP_GUIDE.md](./SETUP_GUIDE.md) for step-by-step instructions!
