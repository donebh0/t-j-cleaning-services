/**
 * T&J Cleaning Services - Google Sheets Automation Script
 * 
 * This script automates:
 * 1. Sending "approved" confirmation emails to customers
 * 2. Sending review follow-up emails when a cleaning is marked complete
 * 
 * Installation:
 * 1. Open your Google Sheet
 * 2. Go to Extensions > Apps Script
 * 3. Copy and paste this entire script
 * 4. Save and authorize the script
 * 5. Set up triggers for onEdit and onOpen
 */

// Configuration - Update these with your actual values
const WEBHOOK_URL = 'https://your-vercel-app.vercel.app/api/';
const REVIEW_EMAIL_API_KEY = 'your-api-key-from-vercel';
const SHEET_NAME = 'Requests';

// Column indices (based on the sheet structure)
const COLUMNS = {
    timestamp: 0,
    name: 1,
    email: 2,
    phone: 3,
    address: 4,
    squareFootage: 5,
    bedrooms: 6,
    bathrooms: 7,
    serviceType: 8,
    price: 9,
    date: 10,
    time: 11,
    specialRequests: 12,
    status: 13,
    notes: 14,
    emailForReview: 15
};

/**
 * Creates a custom menu when the sheet opens
 */
function onOpen() {
    const ui = SpreadsheetApp.getUi();
    ui.createMenu('T&J Cleaning')
        .addItem('Send Confirmation Email', 'sendConfirmationEmail')
        .addItem('Send Review Email', 'sendReviewEmail')
        .addItem('Setup Triggers', 'setupTriggers')
        .addToUi();
}

/**
 * Handles automatic actions when cells are edited
 */
function onEdit(e) {
    const sheet = e.source.getActiveSheet();
    
    // Only process the Requests sheet
    if (sheet.getName() !== SHEET_NAME) return;
    
    const range = e.range;
    const row = range.getRow();
    const column = range.getColumn();
    
    // Check if Status column (column 14) was edited
    if (column === COLUMNS.status + 1) {
        const status = range.getValue();
        
        if (status === 'Approved') {
            // Send confirmation email to customer
            sendApprovalEmail(row, sheet);
        } else if (status === 'Completed') {
            // Schedule review email (send after 2 hours)
            scheduleReviewEmail(row, sheet);
        }
    }
}

/**
 * Sends an approval confirmation email to the customer
 */
function sendApprovalEmail(row, sheet) {
    try {
        const data = getRowData(row, sheet);
        
        if (!data.email) {
            Logger.log('No email found for row ' + row);
            return;
        }
        
        const subject = 'Your T&J Cleaning Service - CONFIRMED! ✓';
        const message = `
            <h2>Your cleaning is confirmed!</h2>
            <p>Hi ${data.name},</p>
            
            <p>Great news! We've confirmed your cleaning service request. Here are your appointment details:</p>
            
            <h3>Appointment Details</h3>
            <ul>
                <li><strong>Date:</strong> ${data.date}</li>
                <li><strong>Time:</strong> ${data.time}</li>
                <li><strong>Address:</strong> ${data.address}</li>
                <li><strong>Service:</strong> ${data.serviceType}</li>
            </ul>
            
            ${data.specialRequests ? `<p><strong>Special Requests:</strong> ${data.specialRequests}</p>` : ''}
            
            <h3>What to Expect</h3>
            <ul>
                <li>Our team will arrive promptly at the scheduled time</li>
                <li>We'll complete a thorough ${data.serviceType.toLowerCase()} of your space</li>
                <li>You'll receive a follow-up message when we're done</li>
            </ul>
            
            <p><strong>Questions before your appointment?</strong> Call us at (555) 123-4567</p>
            
            <p>Best regards,<br>T&J Cleaning Services</p>
        `;
        
        // Send email directly using Apps Script
        GmailApp.sendEmail(data.email, subject, message, {
            htmlBody: message,
            name: 'T&J Cleaning Services'
        });
        
        Logger.log('Approval email sent to ' + data.email);
        
        // Update the "Notes" column to indicate email was sent
        sheet.getRange(row, COLUMNS.notes + 1).setValue('Confirmation email sent');
        
    } catch (error) {
        Logger.log('Error sending approval email: ' + error.toString());
        sheet.getRange(row, COLUMNS.notes + 1).setValue('Error sending email: ' + error.toString());
    }
}

/**
 * Schedules a review email to be sent 2 hours after completion
 */
function scheduleReviewEmail(row, sheet) {
    try {
        const data = getRowData(row, sheet);
        
        if (!data.email) {
            Logger.log('No email found for row ' + row);
            return;
        }
        
        // Option 1: Send immediately (if using Vercel API)
        // This assumes your cleaning is already done
        sendReviewViaWebhook(data);
        
        // Option 2: Use Apps Script to schedule (creates a time-based trigger)
        // Uncomment below to use this method instead
        // ScriptApp.newTrigger('sendReviewEmailTrigger_' + row)
        //     .timeBased()
        //     .after(2 * 60 * 60 * 1000) // 2 hours in milliseconds
        //     .create();
        
        sheet.getRange(row, COLUMNS.notes + 1).setValue('Review email scheduled');
        
    } catch (error) {
        Logger.log('Error scheduling review email: ' + error.toString());
    }
}

/**
 * Sends review email via Vercel webhook
 */
function sendReviewViaWebhook(data) {
    try {
        const options = {
            method: 'post',
            contentType: 'application/json',
            headers: {
                'x-api-key': REVIEW_EMAIL_API_KEY
            },
            payload: JSON.stringify({
                customerName: data.name,
                customerEmail: data.email
            }),
            muteHttpExceptions: true
        };
        
        const response = UrlFetchApp.fetch(
            WEBHOOK_URL + 'review-email',
            options
        );
        
        const responseCode = response.getResponseCode();
        if (responseCode === 200) {
            Logger.log('Review email webhook successful for ' + data.email);
        } else {
            Logger.log('Review email webhook failed: ' + response.getContentText());
        }
        
    } catch (error) {
        Logger.log('Error calling review email webhook: ' + error.toString());
    }
}

/**
 * Alternative: Send review email directly using Apps Script
 * (No webhook needed, but requires Gmail access)
 */
function sendReviewEmailDirect(row, sheet) {
    try {
        const data = getRowData(row, sheet);
        
        if (!data.email) {
            Logger.log('No email found for row ' + row);
            return;
        }
        
        const subject = "How did we do? Leave a review for T&J Cleaning";
        const message = `
            <h2>Thank you for choosing T&J Cleaning Services!</h2>
            <p>Hi ${data.name},</p>
            
            <p>We hope you loved your recent cleaning! Your feedback means the world to us and helps other customers make informed decisions.</p>
            
            <h3>Share Your Experience</h3>
            <p>We'd love if you could take just 2 minutes to leave a review on Google Maps. Your honest feedback helps us improve and reach more people who need our services.</p>
            
            <p><strong><a href="https://www.google.com/maps/search/T&J+Cleaning+Services">⭐ Leave a Review on Google Maps</a></strong></p>
            
            <p>Alternatively, you can review us on:</p>
            <ul>
                <li><a href="https://www.yelp.com/">Yelp</a></li>
                <li><a href="https://www.thumbtack.com/">Thumbtack</a></li>
                <li>Or reply to this email with your feedback</li>
            </ul>
            
            <p><strong>Questions or concerns?</strong> Please contact us directly at (555) 123-4567</p>
            
            <p>Best regards,<br>T&J Cleaning Services</p>
        `;
        
        GmailApp.sendEmail(data.email, subject, message, {
            htmlBody: message,
            name: 'T&J Cleaning Services'
        });
        
        Logger.log('Review email sent to ' + data.email);
        
    } catch (error) {
        Logger.log('Error sending review email: ' + error.toString());
    }
}

/**
 * Gets data from a row in the sheet
 */
function getRowData(row, sheet) {
    const values = sheet.getRange(row, 1, 1, Object.keys(COLUMNS).length).getValues()[0];
    
    return {
        timestamp: values[COLUMNS.timestamp],
        name: values[COLUMNS.name],
        email: values[COLUMNS.email],
        phone: values[COLUMNS.phone],
        address: values[COLUMNS.address],
        squareFootage: values[COLUMNS.squareFootage],
        bedrooms: values[COLUMNS.bedrooms],
        bathrooms: values[COLUMNS.bathrooms],
        serviceType: values[COLUMNS.serviceType],
        price: values[COLUMNS.price],
        date: values[COLUMNS.date],
        time: values[COLUMNS.time],
        specialRequests: values[COLUMNS.specialRequests],
        status: values[COLUMNS.status],
        notes: values[COLUMNS.notes]
    };
}

/**
 * Sets up triggers for automatic actions
 * Run this function once to set up the automation
 */
function setupTriggers() {
    const triggers = ScriptApp.getProjectTriggers();
    
    // Remove existing triggers
    triggers.forEach(function(trigger) {
        ScriptApp.deleteTrigger(trigger);
    });
    
    // Create new triggers
    ScriptApp.newTrigger('onOpen')
        .forSpreadsheet(SpreadsheetApp.getActive())
        .onOpen()
        .create();
    
    ScriptApp.newTrigger('onEdit')
        .forSpreadsheet(SpreadsheetApp.getActive())
        .onEdit()
        .create();
    
    SpreadsheetApp.getUi().alert('Triggers set up successfully!');
}

/**
 * Manual trigger to send confirmation email
 * Call this from the menu to manually send approval email to selected row
 */
function sendConfirmationEmail() {
    const sheet = SpreadsheetApp.getActiveSheet();
    const row = sheet.getActiveRange().getRow();
    
    if (row === 1) {
        SpreadsheetApp.getUi().alert('Please select a data row, not the header');
        return;
    }
    
    sendApprovalEmail(row, sheet);
    SpreadsheetApp.getUi().alert('Confirmation email sent to ' + getRowData(row, sheet).name);
}

/**
 * Manual trigger to send review email
 * Call this from the menu to manually send review email to selected row
 */
function sendReviewEmail() {
    const sheet = SpreadsheetApp.getActiveSheet();
    const row = sheet.getActiveRange().getRow();
    
    if (row === 1) {
        SpreadsheetApp.getUi().alert('Please select a data row, not the header');
        return;
    }
    
    sendReviewEmailDirect(row, sheet);
    SpreadsheetApp.getUi().alert('Review email sent to ' + getRowData(row, sheet).name);
}
