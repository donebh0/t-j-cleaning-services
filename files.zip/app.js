// Pricing calculations
const PRICING_RULES = {
    base: 50,
    perSquareFoot: 0.15,
    bedroomMultiplier: 25,
    bathroomMultiplier: 35,
    serviceMultipliers: {
        residential: 1.0,
        deep: 1.5,
        office: 1.2
    }
};

// Quote Form Handler
const quoteForm = document.getElementById('quoteForm');
const quoteResult = document.getElementById('quoteResult');
const estimatedPrice = document.getElementById('estimatedPrice');
const quoteDetails = document.getElementById('quoteDetails');
const scheduleBtn = document.getElementById('scheduleBtn');
const recalculateBtn = document.getElementById('recalculateBtn');

// Store quote data for scheduling
let currentQuote = {};

quoteForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const squareFootage = parseFloat(document.getElementById('squareFootage').value);
    const bedrooms = parseFloat(document.getElementById('bedrooms').value);
    const bathrooms = parseFloat(document.getElementById('bathrooms').value);
    const serviceType = document.getElementById('serviceType').value;
    
    // Validate inputs
    if (!squareFootage || squareFootage < 100) {
        alert('Please enter a valid square footage (minimum 100)');
        return;
    }
    
    // Calculate price
    let price = PRICING_RULES.base;
    price += squareFootage * PRICING_RULES.perSquareFoot;
    price += bedrooms * PRICING_RULES.bedroomMultiplier;
    price += bathrooms * PRICING_RULES.bathroomMultiplier;
    price = price * PRICING_RULES.serviceMultipliers[serviceType];
    
    // Round to nearest dollar
    price = Math.round(price);
    
    // Store quote data
    currentQuote = {
        squareFootage,
        bedrooms,
        bathrooms,
        serviceType,
        estimatedPrice: price
    };
    
    // Display result
    estimatedPrice.textContent = price.toLocaleString();
    
    const serviceLabel = {
        residential: 'Residential Cleaning',
        deep: 'Deep Cleaning',
        office: 'Office Cleaning'
    }[serviceType];
    
    quoteDetails.innerHTML = `
        <strong>${serviceLabel}</strong><br>
        ${squareFootage.toLocaleString()} sq ft • ${bedrooms} bed • ${bathrooms} bath
    `;
    
    quoteForm.style.display = 'none';
    quoteResult.style.display = 'block';
    
    // Scroll to result
    quoteResult.scrollIntoView({ behavior: 'smooth' });
});

// Schedule button handler
scheduleBtn.addEventListener('click', function() {
    document.getElementById('schedule').style.display = 'block';
    document.getElementById('schedule').scrollIntoView({ behavior: 'smooth' });
});

// Recalculate button handler
recalculateBtn.addEventListener('click', function() {
    quoteForm.reset();
    quoteForm.style.display = 'block';
    quoteResult.style.display = 'none';
    document.getElementById('quote').scrollIntoView({ behavior: 'smooth' });
});

// Schedule Form Handler
const scheduleForm = document.getElementById('scheduleForm');
const scheduleSuccess = document.getElementById('scheduleSuccess');

scheduleForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        // Quote info
        squareFootage: currentQuote.squareFootage,
        bedrooms: currentQuote.bedrooms,
        bathrooms: currentQuote.bathrooms,
        serviceType: currentQuote.serviceType,
        estimatedPrice: currentQuote.estimatedPrice,
        
        // Customer info
        customerName: document.getElementById('customerName').value,
        customerEmail: document.getElementById('customerEmail').value,
        customerPhone: document.getElementById('customerPhone').value,
        address: document.getElementById('address').value,
        preferredDate: document.getElementById('preferredDate').value,
        preferredTime: document.getElementById('preferredTime').value,
        specialRequests: document.getElementById('specialRequests').value,
        submissionTime: new Date().toISOString()
    };
    
    try {
        // Disable button during submission
        const submitBtn = scheduleForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        // Submit to backend
        const response = await fetch('/api/schedule', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to submit form');
        }
        
        const data = await response.json();
        
        // Show success message
        scheduleForm.style.display = 'none';
        scheduleSuccess.style.display = 'block';
        
        // Reset form
        scheduleForm.reset();
        scheduleForm.style.display = 'block';
        
        // Scroll to success message
        scheduleSuccess.scrollIntoView({ behavior: 'smooth' });
        
        // Reset button
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Service Request';
        
    } catch (error) {
        console.error('Error:', error);
        alert('There was an error submitting your request. Please try again or contact us directly.');
        
        const submitBtn = scheduleForm.querySelector('button[type="submit"]');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Service Request';
    }
});

// Set minimum date to today
document.getElementById('preferredDate').addEventListener('load', function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('preferredDate').min = today;
});

// Set minimum date on page load
window.addEventListener('load', function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('preferredDate').min = today;
});

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Form validation helper
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Add real-time validation feedback
const emailInput = document.getElementById('customerEmail');
if (emailInput) {
    emailInput.addEventListener('blur', function() {
        if (this.value && !validateEmail(this.value)) {
            this.classList.add('error');
        } else {
            this.classList.remove('error');
        }
    });
}

// Google Sheets Integration Helper
// This function would be called by the backend to log data to Google Sheets
// For now, we're handling it server-side

console.log('T&J Cleaning Services - App loaded');
