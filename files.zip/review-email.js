import nodemailer from 'nodemailer';

// Initialize email service
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_PASSWORD
    }
});

// Alternative: Use SendGrid if available
async function getEmailTransporter() {
    if (process.env.SENDGRID_API_KEY) {
        const sgTransport = require('nodemailer-sendgrid-transport');
        return nodemailer.createTransport(
            sgTransport({
                auth: {
                    api_key: process.env.SENDGRID_API_KEY
                }
            })
        );
    }
    return transporter;
}

// Send review request email
async function sendReviewRequestEmail(customerName, customerEmail) {
    const mailOptions = {
        from: process.env.GMAIL_USER || 'noreply@tjcleaning.com',
        to: customerEmail,
        subject: "How did we do? Leave a review for T&J Cleaning",
        html: `
            <h2>Thank you for choosing T&J Cleaning Services!</h2>
            <p>Hi ${customerName},</p>
            
            <p>We hope you loved your recent cleaning! Your feedback means the world to us and helps other customers make informed decisions.</p>
            
            <h3>Share Your Experience</h3>
            <p>We'd love if you could take just 2 minutes to leave a review on Google Maps. Your honest feedback helps us improve and reach more people who need our services.</p>
            
            <table style="margin: 30px 0; text-align: center;">
                <tr>
                    <td style="background-color: #FF9500; padding: 15px 30px; border-radius: 6px;">
                        <a href="https://www.google.com/maps/search/T&J+Cleaning+Services" style="color: white; text-decoration: none; font-weight: bold; font-size: 16px;">
                            ⭐ Leave a Review on Google Maps
                        </a>
                    </td>
                </tr>
            </table>
            
            <p>Alternatively, you can:</p>
            <ul>
                <li><a href="https://www.yelp.com/search?find_desc=T&J+Cleaning&find_loc=">Review us on Yelp</a></li>
                <li><a href="https://www.thumbtack.com/">Find us on Thumbtack</a></li>
                <li>Reply to this email with your feedback</li>
            </ul>
            
            <h3>Need Another Cleaning?</h3>
            <p>Don't forget - we offer flexible scheduling for regular maintenance! <a href="https://tjcleaning.com#quote">Get your next quote here</a>.</p>
            
            <p><strong>Questions or concerns?</strong> Please contact us directly at (555) 123-4567 or reply to this email. We want to make things right if you weren't completely satisfied.</p>
            
            <p style="margin-top: 30px; color: #999; font-size: 12px;">
                Best regards,<br>
                The T&J Cleaning Services Team<br>
                <a href="https://tjcleaning.com">tjcleaning.com</a>
            </p>
        `
    };
    
    const mailTransport = await getEmailTransporter();
    await mailTransport.sendMail(mailOptions);
}

// Main handler
// This endpoint can be called:
// 1. By a Google Sheets App Script when status is changed to "Completed"
// 2. By a Vercel cron job (requires Vercel Pro)
// 3. Manually via webhook
export default async function handler(req, res) {
    // Allow CORS
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');
    
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }
    
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }
    
    try {
        // Verify the request is from a trusted source
        // You can add an API key check here
        const apiKey = req.headers['x-api-key'];
        if (apiKey !== process.env.REVIEW_EMAIL_API_KEY && process.env.REVIEW_EMAIL_API_KEY) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        
        const { customerName, customerEmail } = req.body;
        
        if (!customerName || !customerEmail) {
            return res.status(400).json({ error: 'Missing customer name or email' });
        }
        
        // Send review request email
        await sendReviewRequestEmail(customerName, customerEmail);
        
        return res.status(200).json({ 
            success: true,
            message: 'Review email sent successfully'
        });
        
    } catch (error) {
        console.error('Error sending review email:', error);
        return res.status(500).json({ 
            error: 'Failed to send review email',
            message: error.message 
        });
    }
}
