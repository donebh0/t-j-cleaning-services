import { google } from 'googleapis';
import nodemailer from 'nodemailer';

const sheets = google.sheets('v4');

// Initialize Google Sheets authentication
// You'll need to set up a Google Service Account and add credentials to Vercel environment variables
async function getGoogleSheetsAuth() {
    const auth = new google.auth.GoogleAuth({
        credentials: {
            type: 'service_account',
            project_id: process.env.GOOGLE_PROJECT_ID,
            private_key_id: process.env.GOOGLE_PRIVATE_KEY_ID,
            private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
            client_email: process.env.GOOGLE_CLIENT_EMAIL,
            client_id: process.env.GOOGLE_CLIENT_ID,
            auth_uri: 'https://accounts.google.com/o/oauth2/auth',
            token_uri: 'https://oauth2.googleapis.com/token'
        },
        scopes: ['https://www.googleapis.com/auth/spreadsheets']
    });
    return auth;
}

// Initialize email service
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_PASSWORD
    }
});

// Alternative: Use SendGrid if available
async function getEmailTransporter() {
    if (process.env.SENDGRID_API_KEY) {
        const sgTransport = require('nodemailer-sendgrid-transport');
        return nodemailer.createTransport(
            sgTransport({
                auth: {
                    api_key: process.env.SENDGRID_API_KEY
                }
            })
        );
    }
    return transporter;
}

// Format phone number for display
function formatPhone(phone) {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 10) {
        return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
}

// Send confirmation email to customer
async function sendCustomerConfirmationEmail(data) {
    const mailOptions = {
        from: process.env.GMAIL_USER || 'noreply@tjcleaning.com',
        to: data.customerEmail,
        subject: 'Your T&J Cleaning Service Request - Confirmation',
        html: `
            <h2>Thank you for choosing T&J Cleaning Services!</h2>
            <p>Hello ${data.customerName},</p>
            <p>We've received your cleaning service request. Here are the details:</p>
            
            <h3>Service Details</h3>
            <ul>
                <li><strong>Service Type:</strong> ${formatServiceType(data.serviceType)}</li>
                <li><strong>Square Footage:</strong> ${data.squareFootage.toLocaleString()} sq ft</li>
                <li><strong>Bedrooms:</strong> ${data.bedrooms}</li>
                <li><strong>Bathrooms:</strong> ${data.bathrooms}</li>
                <li><strong>Estimated Price:</strong> $${data.estimatedPrice}</li>
            </ul>
            
            <h3>Preferred Appointment</h3>
            <ul>
                <li><strong>Date:</strong> ${formatDate(data.preferredDate)}</li>
                <li><strong>Time:</strong> ${data.preferredTime}</li>
                <li><strong>Address:</strong> ${data.address}</li>
            </ul>
            
            ${data.specialRequests ? `<p><strong>Special Requests:</strong> ${data.specialRequests}</p>` : ''}
            
            <p>We'll review your request and confirm your appointment within 24 hours. You'll receive another email with the final confirmation and any additional details.</p>
            
            <p><strong>Questions?</strong> Contact us at (555) 123-4567 or reply to this email.</p>
            
            <p>Best regards,<br>The T&J Cleaning Services Team</p>
        `
    };
    
    const mailTransport = await getEmailTransporter();
    await mailTransport.sendMail(mailOptions);
}

// Send pending approval email to business owner
async function sendOwnerNotificationEmail(data) {
    const mailOptions = {
        from: process.env.GMAIL_USER || 'noreply@tjcleaning.com',
        to: process.env.OWNER_EMAIL,
        subject: `New Cleaning Request - ${data.customerName}`,
        html: `
            <h2>New Service Request Received</h2>
            <p><strong>Customer:</strong> ${data.customerName}</p>
            <p><strong>Email:</strong> ${data.customerEmail}</p>
            <p><strong>Phone:</strong> ${formatPhone(data.customerPhone)}</p>
            
            <h3>Service Details</h3>
            <ul>
                <li><strong>Type:</strong> ${formatServiceType(data.serviceType)}</li>
                <li><strong>Square Footage:</strong> ${data.squareFootage.toLocaleString()} sq ft</li>
                <li><strong>Bedrooms:</strong> ${data.bedrooms}</li>
                <li><strong>Bathrooms:</strong> ${data.bathrooms}</li>
                <li><strong>Estimated Price:</strong> $${data.estimatedPrice}</li>
            </ul>
            
            <h3>Requested Appointment</h3>
            <ul>
                <li><strong>Date:</strong> ${formatDate(data.preferredDate)}</li>
                <li><strong>Time:</strong> ${data.preferredTime}</li>
                <li><strong>Address:</strong> ${data.address}</li>
            </ul>
            
            ${data.specialRequests ? `<p><strong>Special Requests:</strong> ${data.specialRequests}</p>` : ''}
            
            <p><a href="https://docs.google.com/spreadsheets/d/${process.env.GOOGLE_SHEET_ID}">View in Google Sheets and click Approve/Deny</a></p>
        `
    };
    
    const mailTransport = await getEmailTransporter();
    await mailTransport.sendMail(mailOptions);
}

// Append data to Google Sheet
async function appendToGoogleSheet(data) {
    const auth = await getGoogleSheetsAuth();
    
    const values = [
        [
            new Date(data.submissionTime).toLocaleString(),
            data.customerName,
            data.customerEmail,
            data.customerPhone,
            data.address,
            data.squareFootage,
            data.bedrooms,
            data.bathrooms,
            formatServiceType(data.serviceType),
            `$${data.estimatedPrice}`,
            formatDate(data.preferredDate),
            data.preferredTime,
            data.specialRequests || '',
            'Pending', // Status column for approval
            '', // Notes column
            data.customerEmail // For review email follow-up
        ]
    ];
    
    const request = {
        spreadsheetId: process.env.GOOGLE_SHEET_ID,
        range: 'Requests!A:P',
        valueInputOption: 'USER_ENTERED',
        resource: {
            values: values
        },
        auth: auth
    };
    
    await sheets.spreadsheets.values.append(request);
}

// Helper functions
function formatServiceType(type) {
    const types = {
        residential: 'Residential Cleaning',
        deep: 'Deep Cleaning',
        office: 'Office Cleaning'
    };
    return types[type] || type;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// Main handler
export default async function handler(req, res) {
    // Allow CORS
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');
    
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }
    
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }
    
    try {
        const data = req.body;
        
        // Validate required fields
        if (!data.customerName || !data.customerEmail || !data.customerPhone || !data.address) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        
        // Send confirmation email to customer
        await sendCustomerConfirmationEmail(data);
        
        // Send notification to owner
        await sendOwnerNotificationEmail(data);
        
        // Append to Google Sheets
        await appendToGoogleSheet(data);
        
        return res.status(200).json({ 
            success: true,
            message: 'Request submitted successfully'
        });
        
    } catch (error) {
        console.error('Error processing request:', error);
        return res.status(500).json({ 
            error: 'Failed to process request',
            message: error.message 
        });
    }
}
