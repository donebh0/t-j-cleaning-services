# T&J Cleaning Services - Pre-Launch Checklist

Use this checklist to ensure everything is configured correctly before going live.

---

## 📋 Phase 1: Development Setup

- [ ] All files downloaded/cloned to local machine
- [ ] `package.json` and `vercel.json` are in project root
- [ ] All folders created: `api/`, `css/`, `js/`
- [ ] No `.env` file committed (only `.env.example`)

### Website Files
- [ ] `index.html` is in root
- [ ] `css/style.css` exists and loads
- [ ] `js/app.js` exists and loads
- [ ] All images are accessible (no 404 errors)

### API Files
- [ ] `api/schedule.js` exists
- [ ] `api/review-email.js` exists
- [ ] `sheets-automation.gs` is ready to copy

---

## 🔧 Phase 2: Google Cloud Setup

### Service Account Creation
- [ ] Google Cloud Project created
- [ ] Google Sheets API enabled
- [ ] Gmail API enabled (if using email)
- [ ] Service Account created with Editor role
- [ ] Service Account key downloaded (JSON file)
- [ ] JSON file safely stored (never commit to git)

### From Service Account JSON, I Have:
- [ ] `project_id`
- [ ] `private_key_id`
- [ ] `private_key` (full multi-line key)
- [ ] `client_email`
- [ ] `client_id`

---

## 📊 Phase 3: Google Sheets Setup

### Sheet Creation
- [ ] New Google Sheet created
- [ ] Named: "T&J Cleaning - Service Requests"
- [ ] Column headers added (A-P)
- [ ] Header row formatted nicely

### Column Headers Verified
- [ ] A: Timestamp
- [ ] B: Name
- [ ] C: Email
- [ ] D: Phone
- [ ] E: Address
- [ ] F: Sq Ft
- [ ] G: Bedrooms
- [ ] H: Bathrooms
- [ ] I: Service Type
- [ ] J: Price
- [ ] K: Date
- [ ] L: Time
- [ ] M: Special Requests
- [ ] N: Status
- [ ] O: Notes
- [ ] P: Email

### Sheet Sharing
- [ ] Sheet ID copied from URL
- [ ] Service account email added with Editor access
- [ ] Confirmation that service account can edit

---

## 📧 Phase 4: Email Setup

Choose ONE email method:

### Option A: Gmail
- [ ] Google account with 2-Step Verification enabled
- [ ] Gmail App Password generated
- [ ] 16-character app password copied
- [ ] Tested: Can send emails manually to verify credentials

### Option B: SendGrid
- [ ] SendGrid account created
- [ ] API Key generated with "Mail Send" permission
- [ ] API Key copied and saved safely

### Email Testing
- [ ] Can send test email successfully
- [ ] Email appears in inbox within 5 minutes
- [ ] No spam folder issues

---

## 🚀 Phase 5: Vercel Deployment

### Project Creation
- [ ] Vercel account created
- [ ] Project created or imported from GitHub
- [ ] Vercel CLI installed (optional, for local testing)

### Environment Variables Set in Vercel
- [ ] GOOGLE_PROJECT_ID
- [ ] GOOGLE_PRIVATE_KEY_ID
- [ ] GOOGLE_PRIVATE_KEY (with newline characters)
- [ ] GOOGLE_CLIENT_EMAIL
- [ ] GOOGLE_CLIENT_ID
- [ ] GOOGLE_SHEET_ID
- [ ] GMAIL_USER or SENDGRID_API_KEY (one of these)
- [ ] GMAIL_PASSWORD (if using Gmail)
- [ ] OWNER_EMAIL
- [ ] REVIEW_EMAIL_API_KEY

### Deployment
- [ ] All code pushed to repository (or uploaded)
- [ ] Deployment initiated and succeeded
- [ ] No build errors in Vercel dashboard
- [ ] Website accessible at vercel URL

### Post-Deployment
- [ ] Website loads correctly
- [ ] No 404 errors for CSS/JS files
- [ ] Images load properly
- [ ] Website is responsive (test on mobile)

---

## 🧪 Phase 6: Functionality Testing

### Quote Calculator Test
- [ ] Can access quote form
- [ ] Can enter square footage
- [ ] Can select bedrooms/bathrooms
- [ ] Can select service type
- [ ] Quote calculates correctly
- [ ] "Schedule Service" button appears
- [ ] Can click "Recalculate" to go back

### Scheduling Form Test
- [ ] Scheduling form appears after quote
- [ ] Can enter customer name
- [ ] Can enter email address
- [ ] Can enter phone number
- [ ] Can enter address
- [ ] Can select date (tomorrow or later)
- [ ] Can select time slot
- [ ] Can enter special requests
- [ ] Form submits successfully
- [ ] Success message appears

### Email Testing - Customer Confirmation
- [ ] Check email for confirmation email
- [ ] Email received within 5 minutes
- [ ] Email contains all customer info
- [ ] Email contains quote details
- [ ] Email has correct formatting
- [ ] Email has business contact info

### Email Testing - Owner Notification
- [ ] Check owner email inbox
- [ ] Owner notification received
- [ ] Contains customer details
- [ ] Contains link to Google Sheets
- [ ] Contains all booking information

### Google Sheets Integration
- [ ] New row appears in Google Sheet
- [ ] All data correctly filled in
- [ ] Timestamp is correct
- [ ] All customer info present
- [ ] Quote price calculated correctly
- [ ] Status shows "Pending"

### Approval Workflow Test
- [ ] Open Google Sheet
- [ ] Find test request row
- [ ] Change Status from "Pending" to "Approved"
- [ ] Wait 30 seconds for trigger
- [ ] Check customer email for approval confirmation
- [ ] Email has appointment details
- [ ] Email has correct date/time

### Review Email Test (if automation enabled)
- [ ] Change Status to "Completed"
- [ ] Wait 30 seconds for trigger
- [ ] Check customer email for review request
- [ ] Email contains review links
- [ ] Google Maps link is correct
- [ ] Yelp link is functional

---

## 🎨 Phase 7: Customization

### Business Information Updated
- [ ] Phone number changed (search "555-123-4567" and replace)
- [ ] Email changed (search "info@tjcleaning.com" and replace)
- [ ] Business name correct throughout
- [ ] Hours updated if displayed
- [ ] Address updated if displayed

### Branding
- [ ] Colors match your brand (CSS variables updated)
- [ ] Logo added if desired
- [ ] Service types match your offerings
- [ ] Pricing multipliers are accurate
- [ ] Service descriptions are correct

### Text & Copy
- [ ] Hero section headline customized
- [ ] Service descriptions updated
- [ ] Benefit statements are accurate
- [ ] Contact information is current
- [ ] Email templates mention your business

---

## 🔐 Phase 8: Security & Performance

### Security Checks
- [ ] No sensitive data in git commits
- [ ] `.env` not committed to version control
- [ ] Environment variables only in Vercel
- [ ] API keys are random/secure
- [ ] Private key has no extra whitespace
- [ ] CORS configured correctly
- [ ] No console.log statements revealing data

### Performance Checks
- [ ] Website loads in under 3 seconds
- [ ] Mobile site loads quickly
- [ ] Forms submit without delays
- [ ] No 404 errors in console
- [ ] No JavaScript errors in console

### Mobile Testing
- [ ] View on iPhone (Safari)
- [ ] View on Android (Chrome)
- [ ] All buttons are clickable
- [ ] Forms are easy to use
- [ ] Text is readable
- [ ] Images responsive

---

## 📱 Phase 9: Browser Compatibility

Test on these browsers:
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Chrome Mobile
- [ ] Safari Mobile

---

## 📊 Phase 10: Analytics & Monitoring

### Setup Monitoring
- [ ] Vercel deployment monitoring enabled
- [ ] Check Vercel logs for errors
- [ ] Set up error alerts (optional)
- [ ] Google Analytics added (optional)
- [ ] Track form submissions

### Backup Planning
- [ ] Know how to backup Google Sheets
- [ ] Know how to access Vercel logs
- [ ] Have emergency contact method ready
- [ ] Know how to manually send emails if API fails

---

## 🎯 Phase 11: Final Checks Before Launch

### Legal/Compliance
- [ ] Privacy policy ready (if collecting data)
- [ ] Terms of service ready (if needed)
- [ ] Contact info is accurate and monitored
- [ ] Can respond to customer inquiries quickly

### Business Operations
- [ ] Team trained on Google Sheets workflow
- [ ] Owner knows how to approve/deny requests
- [ ] Someone monitors emails daily
- [ ] Know how to send manual follow-ups
- [ ] Backup person assigned for coverage

### Testing One More Time
- [ ] Full workflow test end-to-end
- [ ] Test on mobile device
- [ ] Verify all emails send
- [ ] Check Google Sheets updates
- [ ] Verify quote calculation accuracy

---

## ✅ Phase 12: Launch Readiness

### Final Checklist
- [ ] All tests passing
- [ ] No errors in Vercel logs
- [ ] Website looks professional
- [ ] All contact info correct
- [ ] Team is trained and ready
- [ ] You've done a test booking yourself

### Go Live!
- [ ] Domain configured (if using custom domain)
- [ ] Share website link with team
- [ ] Add link to business listings
- [ ] Promote on social media
- [ ] Email link to existing customers
- [ ] Monitor closely first week

---

## 🚨 Post-Launch Monitoring (First Week)

### Daily Checks
- [ ] Check email for new requests
- [ ] Review Google Sheets for submissions
- [ ] Respond to inquiries within 24 hours
- [ ] Check Vercel logs for errors
- [ ] Monitor website performance

### Weekly Checks
- [ ] Review customer feedback
- [ ] Check email deliverability
- [ ] Verify all automations working
- [ ] Backup Google Sheets
- [ ] Plan improvements for next week

### Issues to Watch For
- [ ] Emails going to spam
- [ ] Quotes calculating incorrectly
- [ ] Google Sheets not updating
- [ ] Website being slow
- [ ] Mobile layout issues
- [ ] Form validation problems

---

## 📞 Support & Escalation

### If Something Breaks
1. Check Vercel logs for error messages
2. Check Gmail/SendGrid for delivery issues
3. Verify Google Sheets has correct columns
4. Test locally with `.env.local` file
5. Review environment variables in Vercel

### Common Issues & Solutions
See SETUP_GUIDE.md "Troubleshooting" section

### When to Revert
- If major feature breaks, revert deployment in Vercel
- Easy one-click rollback available

---

## 🎉 Congratulations!

If you've completed all these checks, your T&J Cleaning Services website is ready to bring in customers!

### Next Steps
1. Monitor first week closely
2. Optimize based on customer feedback
3. Plan future improvements
4. Celebrate your new automated system! 🎊

---

**Last Updated:** January 2024
**For Latest Checks:** See SETUP_GUIDE.md and README.md
