# Google Sheets Setup Guide for T&J Cleaning Services

This guide shows you exactly how to set up the Google Sheet that will receive all your cleaning service requests.

## Quick Setup (5 minutes)

### Step 1: Create a New Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com)
2. Click "Blank" to create a new spreadsheet
3. Name it: "T&J Cleaning - Service Requests"
4. Click "Create"

### Step 2: Set Up Column Headers

Copy this table into Row 1 of your sheet:

| Column | Header | Purpose |
|--------|--------|---------|
| A | Timestamp | When the request was submitted |
| B | Name | Customer's full name |
| C | Email | Customer's email address |
| D | Phone | Customer's phone number |
| E | Address | Service address |
| F | Sq Ft | Square footage of property |
| G | Bedrooms | Number of bedrooms |
| H | Bathrooms | Number of bathrooms |
| I | Service Type | Type of cleaning (Residential/Deep/Office) |
| J | Price | Estimated price |
| K | Date | Preferred service date |
| L | Time | Preferred service time |
| M | Special Requests | Any special instructions |
| N | Status | Request status (Pending/Approved/Denied/Completed) |
| O | Notes | Internal notes |
| P | Email | Customer email (for review email) |

### Step 3: Format the Header Row (Optional but Recommended)

1. Select row 1 (click the row number)
2. Make it bold: Press Ctrl+B (or Cmd+B on Mac)
3. Add a background color:
   - Right-click → Format cells
   - Fill color → Choose a light blue or gray
4. Make text white for better contrast

### Step 4: Get Your Sheet ID

1. Look at the URL in your browser
2. Find the part between `/d/` and `/edit`
3. Copy this long ID - you'll need it for Vercel setup

Example URL:
```
https://docs.google.com/spreadsheets/d/1a2b3c4d5e6f7g8h9i0j/edit
                                       ↑ This is your Sheet ID
```

### Step 5: Share With Your Service Account

1. In your Google Sheet, click "Share" (top right)
2. Copy your Google Service Account email from the JSON file you downloaded
   - It looks like: `tj-cleaning@project.iam.gserviceaccount.com`
3. Paste it into the "Add people or groups" field
4. Select "Editor" permission
5. Uncheck "Notify people"
6. Click "Share"

---

## Workflow: How It Works

### When a Customer Submits a Request

1. **Automatic Row Added** - Your sheet automatically gets a new row with:
   - Timestamp of submission
   - All customer information
   - Quote details
   - Status: "Pending"

2. **You Get Email** - You receive a notification with:
   - Customer details
   - Service information
   - Link to approve/deny

3. **Customer Gets Email** - They receive confirmation their request was received

### When You Approve

1. **Open the Google Sheet**
2. **Find the customer's row**
3. **Click the Status column (N)**
4. **Change from "Pending" to "Approved"**
5. **Automatic Email Sent** - Customer gets a confirmation with appointment details

### When You Complete the Cleaning

1. **Change Status to "Completed"**
2. **Review Email Auto-Sent** - Customer receives review request 2 hours later (if automation enabled)

### Optional: When You Deny

1. **Change Status to "Denied"**
2. (Optional automation can send a "thanks but not available" email)

---

## Advanced Setup: Formulas & Automation

### Optional: Add Automatic Formatting

You can make rows change color based on status:

1. Select all data (Ctrl+A)
2. Format → Conditional formatting
3. Format rules:
   - If Status = "Pending" → Light yellow background
   - If Status = "Approved" → Light green background
   - If Status = "Completed" → Light blue background
   - If Status = "Denied" → Light red background

### Optional: Add Dropdown Lists

Make the Status column easier to update:

1. Click column N header (Status)
2. Right-click → Edit column
3. Scroll to "Data validation"
4. Select "List from a range"
5. Create a small list in an empty area:
   - Pending
   - Approved
   - Completed
   - Denied
6. Reference that range
7. Allow invalid entries → False
8. Click Done

Now you can just click and select from a dropdown!

### Optional: Add Summary Statistics

In a separate area, you can add formulas to track:

```
Total Requests: =COUNTA(B2:B) - 1
Pending Requests: =COUNTIF(N2:N,"Pending")
Approved Today: =COUNTIFS(N2:N,"Approved",A2:A,TODAY())
Revenue This Month: =SUMIFS(J2:J,A2:A,">=1/1/2024",A2:A,"<2/1/2024")
```

---

## Viewing Your Data

### Filter by Status
1. Click the filter icon in the header row
2. Click Status column
3. Select which statuses to view

### Sort by Date
1. Click the filter icon
2. Click Date column
3. Sort from newest to oldest

### Find a Specific Request
- Use Ctrl+F to search by name, email, or phone

---

## Sheet Backup & Sharing

### Back Up Your Data
1. Click "File" → "Download" → "CSV (.csv)"
2. Save this file to your computer
3. Do this monthly to keep backups

### Share with Team Members
1. Click "Share" in the top right
2. Add team members' email addresses
3. Give them "Editor" or "Viewer" access
4. They can see all requests without accessing your account

---

## Troubleshooting

### Data Not Appearing?
- Check that the service account was invited to the sheet
- Verify GOOGLE_SHEET_ID is correct (no spaces or typos)
- Check Vercel logs for API errors

### Emails Not Sending When Status Changes?
- Verify Google Apps Script is installed and running
- Check that Apps Script triggers are enabled
- Make sure column N is exactly named "Status"
- Test manually: T&J Cleaning menu → Send Confirmation Email

### Can't Type in Status Column?
- If you set up data validation, only allowed values work
- Or select "Allow invalid entries" to make it flexible

---

## Data You'll Collect

Each request includes:
- **Customer contact info** - Name, email, phone, address
- **Property details** - Square footage, bedrooms, bathrooms
- **Service details** - Type of cleaning, estimated price
- **Preferred date/time** - When they want the cleaning
- **Special requests** - Any specific instructions
- **Timestamp** - Exact date/time they submitted

All this is automatically filled in from the website quote form!

---

## Privacy & Data

### Your Data is Safe
- All data stays in your Google Drive
- Only your service account can access it
- Encrypted in transit (Google's servers)
- You control who has access

### GDPR Compliance
- You own all customer data
- Delete rows anytime to remove customer info
- No third-party data sharing

---

## Monthly Review

At the end of each month, you can:

1. **Review Requests**: See how many requests you got
2. **Track Revenue**: Use formulas to calculate total income
3. **Analyze Trends**: Which service types are most popular?
4. **Archive Old Data**: Delete or move completed requests
5. **Backup**: Download a copy to your computer

---

## Template Download

You can copy our pre-formatted sheet:

1. Go to [this Google Sheet](link-to-template-sheet)
2. Click "File" → "Make a copy"
3. Rename it "T&J Cleaning - Service Requests"
4. Use that instead of creating from scratch

---

## Next Steps

1. ✅ Create your Google Sheet
2. ✅ Add column headers
3. ✅ Get your Sheet ID
4. ✅ Share with your service account
5. ✅ Add Sheet ID to Vercel environment variables
6. ✅ Test by submitting a form
7. ✅ Set up Google Apps Script automation (see SETUP_GUIDE.md)

---

## Quick Reference

### Status Options
- **Pending**: New request, awaiting review
- **Approved**: Confirmed appointment scheduled
- **Completed**: Cleaning finished, review email sent
- **Denied**: Request declined or not available

### Useful Columns
- **Status (N)**: You change this to trigger actions
- **Email (P)**: Auto-filled from customer email (for review emails)
- **Notes (O)**: Write anything (no automation effect)

### No coding required!
- Just click cells to update
- Everything else is automatic

---

**Created for T&J Cleaning Services**
