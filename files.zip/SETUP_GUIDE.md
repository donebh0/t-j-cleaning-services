# T&J Cleaning Services - Complete Setup Guide

This guide will walk you through setting up the entire T&J Cleaning Services website with automation.

## Project Overview

This is a professional cleaning business website with three key automated features:

1. **Instant Quote Form** - Calculates prices based on square footage, bedrooms, and bathrooms
2. **Schedule-to-Sheet** - Submits cleaning requests to Google Sheets and sends email confirmations
3. **Review Loop** - Sends automated review requests 2 hours after cleaning is marked complete

## Prerequisites

- Vercel account (free tier works fine)
- Google account for Google Sheets
- Gmail account or SendGrid account for emails
- GitHub account (optional but recommended)

---

## Step 1: Deploy to Vercel

### Option A: Direct Deploy (Easiest)

1. Go to [vercel.com](https://vercel.com) and sign up if you haven't
2. Click "Add New..." → "Project"
3. Select "Import Git Repository"
4. Paste this repository URL: `https://github.com/yourusername/tj-cleaning`
5. Click "Import"
6. Go to "Settings" → "Environment Variables"
7. Add all the environment variables (see Step 3 below)
8. Click "Deploy"

### Option B: Manual Upload

1. Download all files from this project
2. Go to vercel.com and create a new project
3. Upload the files directly
4. Configure environment variables
5. Deploy

---

## Step 2: Set Up Google Sheets

### 2A: Create the Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com) and create a new sheet
2. Name it "T&J Cleaning - Service Requests"
3. Create the following columns in the header row:

| A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Timestamp | Name | Email | Phone | Address | Sq Ft | Bedrooms | Bathrooms | Service Type | Price | Date | Time | Special Requests | Status | Notes | Email |

4. Make sure the header row (row 1) is formatted
5. Copy the Sheet ID from the URL (the long string between `/d/` and `/edit`)

### 2B: Set Up Google Service Account (for automated sheet updates)

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project: Click "Select a Project" → "New Project"
3. Name it "TJ Cleaning Services"
4. Go to "APIs & Services" → "Enable APIs and Services"
5. Search for "Google Sheets API" and enable it
6. Search for "Gmail API" and enable it
7. Click "Create Credentials" → "Service Account"
8. Fill in the details:
   - Service account name: `tj-cleaning-service`
   - Click "Create and Continue"
   - Grant it "Editor" role
   - Click "Continue"
9. Click "Create Key" → "JSON"
10. A JSON file will download - keep it safe!
11. Open the JSON file and note these values:
    - `project_id`
    - `private_key_id`
    - `private_key`
    - `client_email`
    - `client_id`

### 2C: Share the Sheet with Your Service Account

1. Open your Google Sheet
2. Click "Share"
3. Paste the `client_email` from the JSON file
4. Give it "Editor" access
5. Click "Share"

---

## Step 3: Configure Environment Variables

In Vercel, go to your project → Settings → Environment Variables and add:

### Google Sheets Variables
```
GOOGLE_PROJECT_ID = [your project_id from JSON]
GOOGLE_PRIVATE_KEY_ID = [your private_key_id from JSON]
GOOGLE_PRIVATE_KEY = [your private_key from JSON - keep as multi-line]
GOOGLE_CLIENT_EMAIL = [your client_email from JSON]
GOOGLE_CLIENT_ID = [your client_id from JSON]
GOOGLE_SHEET_ID = [the sheet ID you copied earlier]
```

### Email Variables (Choose ONE option below)

**Option 1: Gmail (Free)**
```
GMAIL_USER = your.email@gmail.com
GMAIL_PASSWORD = [your Google App Password - see below]
OWNER_EMAIL = your.email@gmail.com
```

**To get a Gmail App Password:**
1. Go to [myaccount.google.com](https://myaccount.google.com)
2. Click "Security" in the left menu
3. Enable "2-Step Verification" if you haven't already
4. Scroll down and click "App passwords"
5. Select Mail and Windows Computer
6. Copy the generated 16-character password
7. Use this as your GMAIL_PASSWORD

**Option 2: SendGrid (Recommended for production)**
```
SENDGRID_API_KEY = [your SendGrid API key]
OWNER_EMAIL = your.email@example.com
```

### Other Variables
```
REVIEW_EMAIL_API_KEY = [create a random 32-character string]
```

---

## Step 4: Set Up Google Apps Script Automation

### 4A: Create the Apps Script

1. Open your Google Sheet
2. Click "Extensions" → "Apps Script"
3. Delete the default code
4. Copy and paste the entire content from `sheets-automation.gs`
5. Update these lines with your actual values:
   ```javascript
   const WEBHOOK_URL = 'https://your-vercel-domain.vercel.app/api/';
   const REVIEW_EMAIL_API_KEY = '[same value as in Vercel env vars]';
   ```
6. Click "Save"
7. When prompted, authorize the script to access your Google Account

### 4B: Set Up Triggers

1. Still in the Apps Script editor
2. Click on the "Triggers" icon (alarm clock) on the left sidebar
3. Click "+ Create new trigger" if the automatic triggers aren't set up
4. Or run the `setupTriggers()` function:
   - Click "Run" → `setupTriggers`
   - Authorize when prompted

---

## Step 5: Test Everything

### Test 1: Quote Calculator
1. Go to your website
2. Fill in the quote form with:
   - Square footage: 2000
   - Bedrooms: 3
   - Bathrooms: 2
   - Service type: Residential Cleaning
3. Click "Calculate Quote" - should show an estimated price

### Test 2: Scheduling
1. After getting a quote, click "Schedule Service"
2. Fill in your information:
   - Name: Test Name
   - Email: your.email@gmail.com
   - Phone: (555) 123-4567
   - Address: 123 Test St
   - Date: Tomorrow
   - Time: 10:00 AM
3. Click "Submit Service Request"
4. You should receive:
   - A confirmation email at your customer email
   - A notification email at your owner email
   - The request should appear in your Google Sheet

### Test 3: Approval Email
1. In your Google Sheet, find the test row
2. Change the "Status" column to "Approved"
3. You should receive a confirmation email

### Test 4: Review Email
1. In your Google Sheet, find the test row
2. Change the "Status" column to "Completed"
3. You should receive a review request email

---

## Customization Tips

### Change Pricing Formula

Edit the `PRICING_RULES` object in `js/app.js`:

```javascript
const PRICING_RULES = {
    base: 50,                          // Base price
    perSquareFoot: 0.15,              // Per sq ft
    bedroomMultiplier: 25,            // Per bedroom
    bathroomMultiplier: 35,           // Per bathroom
    serviceMultipliers: {
        residential: 1.0,              // Regular price
        deep: 1.5,                     // 50% more for deep cleaning
        office: 1.2                    // 20% more for office
    }
};
```

### Change Email Templates

Edit the email HTML in:
- `api/schedule.js` - Customer confirmation email
- `api/schedule.js` - Owner notification email
- `api/review-email.js` - Review request email
- `sheets-automation.gs` - Google Sheets automation emails

### Update Contact Information

Edit in `index.html`:
```html
<a href="tel:+15551234567">(555) 123-4567</a>
<a href="mailto:info@tjcleaning.com">info@tjcleaning.com</a>
```

### Change Colors and Styling

Edit the CSS variables in `css/style.css`:

```css
:root {
    --primary-dark: #1F3A6F;      /* Main color */
    --accent: #FF9500;            /* Button/highlight color */
    --text-dark: #1a1a1a;         /* Text color */
    --bg-light: #F5F5F5;          /* Background color */
}
```

---

## Troubleshooting

### Quote form not calculating
- Check browser console for errors (F12)
- Make sure all form fields are filled
- Check that JavaScript is enabled

### Emails not sending
- Check Vercel function logs: Project → Deployments → View Logs
- For Gmail: Make sure 2-step verification is enabled and app password is correct
- For SendGrid: Verify API key is valid
- Check that `OWNER_EMAIL` is set

### Data not appearing in Google Sheet
- Verify `GOOGLE_SHEET_ID` is correct
- Check that the service account has access to the sheet
- Check Vercel logs for authentication errors
- Make sure column names match the script

### Review emails not sending
- Verify the Status column is named exactly "Status"
- Make sure column letters match (column N for Status)
- Check that Apps Script triggers are enabled
- Test manually using the T&J Cleaning menu → Send Review Email

---

## Security Notes

1. **Never commit sensitive data** to version control
2. **Use Vercel environment variables** for all secrets
3. **Keep Google App Passwords** secure
4. **Rotate SendGrid API keys** regularly
5. **Monitor Vercel logs** for errors

---

## Performance & Scaling

- **Current limits**: Vercel free tier handles up to 100 requests/day easily
- **For higher volume**: Upgrade to Vercel Pro
- **Email rate limiting**: Gmail has a ~500 emails/day limit for App Passwords
- **For higher volume emails**: Use SendGrid (no practical limit)

---

## Support

- **Vercel Docs**: https://vercel.com/docs
- **Google Sheets API**: https://developers.google.com/sheets/api
- **Nodemailer Docs**: https://nodemailer.com/

---

## Next Steps

1. Customize the website copy and contact information
2. Add your business logo (update in HTML header area)
3. Set up a custom domain on Vercel
4. Add more stock images (currently using Unsplash)
5. Test all email flows thoroughly
6. Set up monitoring/alerts for API failures

---

Last Updated: January 2024
